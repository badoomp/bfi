AOS.init({
  duration: 600,
});
